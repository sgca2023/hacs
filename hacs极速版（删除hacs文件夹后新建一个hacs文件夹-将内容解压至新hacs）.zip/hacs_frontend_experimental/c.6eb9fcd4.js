import{c as e}from"./c.1024e243.js";const r=r=>{return t=r.entity_id,void 0===(a=r.attributes).friendly_name?e(t).replace(/_/g," "):a.friendly_name||"";var t,a};export{r as c};
